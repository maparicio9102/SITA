<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\Proyectos_Laravel\mi-login\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>