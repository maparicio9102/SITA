<div class="mdc-layout-grid">
    <div class="mdc-layout-grid__inner">
            <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-6-desktop">
                <span class="text-center text-sm-left d-block d-sm-inline-block tx-14">Copyright © 2020</span>
            </div>
           
        </div>
</div><?php /**PATH C:\xampp\htdocs\Proyectos_Laravel\mi-login\resources\views/footer/footer.blade.php ENDPATH**/ ?>