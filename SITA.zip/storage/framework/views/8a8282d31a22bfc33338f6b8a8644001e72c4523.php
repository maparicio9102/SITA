<div class="mdc-layout-grid">
    <div class="mdc-layout-grid__inner">
            <div class="mdc-layout-grid__cell stretch-card mdc-layout-grid__cell--span-6-desktop">
                <span class="text-center text-sm-left d-block d-sm-inline-block tx-14">
                © 2021- Administración de tutorías y asesorías 
                </span>
            </div>           
        </div>
</div><?php /**PATH C:\xampp\htdocs\Proyectos_Laravel\SITA\resources\views/footer/footer.blade.php ENDPATH**/ ?>