<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>SITA</title>
  <!-- plugins:css -->
  
  <LInk href="<?php echo e(asset('/assets/vendors/mdi/css/materialdesignicons.min.css')); ?>" rel="stylesheet">
  <LInk href="<?php echo e(asset('/assets/vendors/css/vendor.bundle.base.css')); ?>" rel="stylesheet">
  <LInk href="<?php echo e(asset('/assets/css/demo/style.css')); ?>" rel="stylesheet">
  <!-- CSS only -->

  <LInk href="<?php echo e(asset('/assets/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
  <script src="<?php echo e(url('assets/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
  <script src="<?php echo e(url('js/funcionesGenerales.js')); ?>"></script>
 
</head>
<body>

<script src="<?php echo e(url('/assets/js/preloader.js')); ?>"></script>

  <div class="body-wrapper">
    <!-- partial:../../partials/_sidebar.html -->
    <aside class="mdc-drawer mdc-drawer--dismissible mdc-drawer--open">
     
      <div class="mdc-drawer__content">
          <?php echo $__env->make('menu.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

      </div>
    </aside>
    <!-- partial -->

    <div class="main-wrapper mdc-drawer-app-content">      
      <header class="mdc-top-app-bar" style="position: -webkit-sticky; position: sticky; top: 0;">
      <!-- mdc-top-app-bar -->
            <?php echo $__env->make('menu.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </header>
      <!-- partial -->     

      <div class="page-wrapper mdc-toolbar-fixed-adjust">
      <!-- page-wrapper mdc-toolbar-fixed-adjust -->
        <main class="content-wrapper">
            <div class="mdc-layout-grid">
                <div class="mdc-layout-grid__inner">                
                    <?php echo $__env->yieldContent('contenido'); ?> 
                </div>
            </div>
        </main>
        
        <footer >
              <?php echo $__env->make('footer.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </footer>
        <!-- partial -->
      </div>
    </div>
  </div>
  <!-- plugins:js -->
  
  <script src="<?php echo e(url('assets/vendors/js/vendor.bundle.base.js')); ?>"></script>
  <script src="<?php echo e(url('assets/js/material.js')); ?>"></script>
  <script src="<?php echo e(url('assets/js/misc.js')); ?>"></script>

  


</body>
</html>
<?php /**PATH C:\xampp\htdocs\Proyectos_Laravel\SITA\resources\views/master.blade.php ENDPATH**/ ?>